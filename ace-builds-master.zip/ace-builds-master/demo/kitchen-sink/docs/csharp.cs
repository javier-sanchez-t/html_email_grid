public void HelloWorld() {
    //Say Hello!
    Console.WriteLine("Hello World");
}